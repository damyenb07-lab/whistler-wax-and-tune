
# Whistler Wax and Tune — Website (Capstone)

This is a simple, responsive, single-page website built for the Whistler Wax and Tune capstone project.

## What's included
- `index.html` — main site
- `styles.css` — dark theme styles
- `script.js` — client-side behavior and date validation
- `assets/logo.png` — logo (generated or placeholder)
- `README.md` — this file

## Booking form (Formspree)
This site is configured to use **Formspree** for bookings. To enable bookings:

1. Create a free form at https://formspree.io/ and get your **form ID**.
2. Replace `<FORM_ID>` in the `action` attribute of the `<form>` element in `index.html` with your Formspree form ID. Example:
   ```html
   <form action="https://formspree.io/f/abcde123" method="POST"> ... </form>
   ```
3. (Optional) Update the default reply-to email in the `email` input if desired.

### Notes about unavailable days
The site blocks booking on **Wednesdays, Thursdays, and Fridays** via client-side validation. Formspree submissions will still be accepted if someone circumvents the client validation; you'll need to manually check dates or set up server-side checks if required.

## Deploying to GitHub Pages
1. Create a GitHub repo (if you haven't already), e.g. `whistler-wax-and-tune`.
2. Commit and push these files to the `main` branch.
3. In your repo settings -> Pages, set the source to the `main` branch and root (`/`).
4. After a minute, your site will be live at `https://<your-github-username>.github.io/<repo-name>/`.

## Customizations
- To change business info (owner, services, prices), edit `index.html`.
- To change theme colors, edit `:root` variables in `styles.css`.

## Privacy & Contact
Email included on the site: damyenbouvier@gmail.com (used only for this project and contact on the website).
