
// Basic client-side behavior: block unavailable weekdays (Wed/Thu/Fri) and validate form
document.addEventListener('DOMContentLoaded', function(){
  const dateInput = document.getElementById('date');
  const form = document.getElementById('bookingForm');
  const formMessage = document.getElementById('formMessage');

  function isUnavailable(date) {
    // JS weekday: 0 Sun ... 6 Sat
    const dow = date.getDay();
    // Unavailable: Wed (3), Thu (4), Fri (5)
    return dow === 3 || dow === 4 || dow === 5;
  }

  function formatDate(d){ return d.toISOString().split('T')[0]; }

  // Ensure min date is today
  const today = new Date();
  dateInput.setAttribute('min', formatDate(today));

  dateInput.addEventListener('input', (e)=>{
    const val = e.target.value;
    if(!val) return;
    const selected = new Date(val + 'T00:00:00');
    if(isUnavailable(selected)){
      formMessage.textContent = 'Selected day is unavailable. Please choose another day (not Wed/Thu/Fri).';
      e.target.value = '';
    } else {
      formMessage.textContent = '';
    }
  });

  // On submit show friendly message and allow Formspree to handle POST.
  form.addEventListener('submit', function(e){
    // Simple client validation for no date value
    if(!dateInput.value){
      e.preventDefault();
      formMessage.textContent = 'Please choose a valid available date for drop-off.';
      return;
    }
    formMessage.textContent = 'Sending booking... You will receive a confirmation by email within 24 hours.';
    // Let the form submit normally (to Formspree)
  });
});
